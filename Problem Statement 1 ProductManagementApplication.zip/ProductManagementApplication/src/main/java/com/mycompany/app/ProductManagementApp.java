package com.mycompany.app;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.mycompany.domain.Product;
import com.mycompany.service.ProductService;

public class ProductManagementApp {

	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ProductService ps = new ProductService();
		int id;
		String name;
		float price;
		String con="";
		int choice;
		String result;
		
		do {
			System.out.println("1:Add, 2: Delete, 3: Update, 4:Display All, 5:SearchByID, 6:Exit");
			System.out.println("Plz enter your choice");
			choice = sc.nextInt();
		
			switch(choice) {
			case 1: System.out.println("Enter the id");
					id = sc.nextInt();
					System.out.println("Enter the name");
					name = sc.next();
					System.out.println("Enter the price");
					price = sc.nextFloat();
					Product prd = new Product(id, name, price);
					result = ps.storeProduct(prd);
					System.out.println(result);
					break;
			case 2:	System.out.println("Enter the id");
					id = sc.nextInt();
					result = ps.deleteProduct(id);
					System.out.println(result);
					break;
					 
			case 3:System.out.println("Enter the id");
					id = sc.nextInt();
					System.out.println("Enter the price");
					price = sc.nextFloat();
					Product prd1 = new Product();
					prd1.setId(id);
					prd1.setPrice(price);
					result = ps.updateProduct(prd1);
					System.out.println(result);
					break;
					
			case 4:List<Product> listOfPrd = ps.getAllProduct();
				   Iterator<Product> i = listOfPrd.iterator();
				   while(i.hasNext()) {
					    System.out.println(i.next()); 
				   }
				   break;
				   
			case 5:System.out.println("Enter the id");
				   id = sc.nextInt();
				   List<Product> listOfPrd1 = ps.findProductByid(id);
				   Iterator<Product> i1 = listOfPrd1.iterator();
				   while(i1.hasNext()) {
					   System.out.println(i1.next()); 
				   }
				   break;
				   
			case 6:break;
			
			default:System.out.println("Wrong choice");
				break;
			}
			System.out.println("do you want to continue?");
			con = sc.next();
		}while(con.equals("y"));
		System.out.println("Thank you visit again!");
	


	}

}
