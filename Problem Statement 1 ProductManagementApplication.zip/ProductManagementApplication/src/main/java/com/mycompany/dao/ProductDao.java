package com.mycompany.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mycompany.dbutil.DBResource;
import com.mycompany.domain.Product;



public class ProductDao {

	public int storeProduct(Product prd) {
		try {
			Connection con=DBResource.getDBConnection();
			PreparedStatement pstmt=con.prepareStatement("Insert into product values(?,?,?)");
			pstmt.setInt(1, prd.getId());
			pstmt.setString(2, prd.getName());
			pstmt.setFloat(3, prd.getPrice());
			int res=pstmt.executeUpdate();
			return res;
		}catch(Exception e) {
			System.out.println(e);
		}
		return 0;
	}
	
	
	
	public int deleteProduct(int id) {
		try {
			Connection con=DBResource.getDBConnection();
			PreparedStatement pstmt=con.prepareStatement("delete from product where id = ?");
			pstmt.setInt(1, id);
			int res=pstmt.executeUpdate();
			return res;
		}catch(Exception e) {
			System.out.println(e);
		}
		return 0;
	}
	
	public int updateProduct(Product prd) {
		try {
			Connection con=DBResource.getDBConnection();
			PreparedStatement pstmt=con.prepareStatement("update product set price = ? where id= ?");
			pstmt.setFloat(1, prd.getPrice());
			pstmt.setInt(2, prd.getId());
			int res=pstmt.executeUpdate();
			return res;
		}catch(Exception e) {
			System.out.println(e);
		}
		return 0;
	}
	
	public List<Product> findAllProduct() {
		List<Product> listOfPrd=new ArrayList<>();
		try {
			Connection con=DBResource.getDBConnection();
			PreparedStatement pstmt=con.prepareStatement("select * from product");
			ResultSet rs=pstmt.executeQuery();
			
			while(rs.next()) {
				Product prd=new Product();
				prd.setId(rs.getInt("id"));
				prd.setName(rs.getString("pname"));
				prd.setPrice(rs.getFloat("price"));
				listOfPrd.add(prd);
			}
			return listOfPrd;
			
		}catch(Exception e) {
			System.out.println(e);
		}
		return null;
	}
	
	public List<Product> findProductByid(int id) {
		List<Product> listOfPrd=new ArrayList<>();
		try {
			Connection con=DBResource.getDBConnection();
			PreparedStatement pstmt=con.prepareStatement("select * from product where id= ?");
			pstmt.setFloat(1, id);
			ResultSet rs=pstmt.executeQuery();
			
			while(rs.next()) {
				Product prd=new Product();
				prd.setId(rs.getInt("id"));
				prd.setName(rs.getString("pname"));
				prd.setPrice(rs.getFloat("price"));
				listOfPrd.add(prd);
			}
			return listOfPrd;
		}catch(Exception e) {
			System.out.println(e);
		}
		return null;
	}
	
	
	
}
