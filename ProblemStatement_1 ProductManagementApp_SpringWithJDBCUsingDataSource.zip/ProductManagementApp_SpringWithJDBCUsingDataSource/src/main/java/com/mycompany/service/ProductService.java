package com.mycompany.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mycompany.dao.ProductDao;
import com.mycompany.domain.Product;

@Service
public class ProductService {
	
	@Autowired
	ProductDao pd=new ProductDao();
	
	public String storeProduct(Product prd) {
		if(pd.storeProduct(prd)>0) {
				return "Record inserted";
			}else {
				return "Record not inserted";
			}
		}
	

	public String deleteProduct(int id) {
		if(pd.deleteProduct(id)>0) {
			return "Record deleted successfully";
		}else {
			return "Record not present";
		}
	}

	public String updateProduct(Product prd) {
		if(pd.updateProduct(prd)>0) {
			return "Record updated successfully";
		}else {
			return "Record not present";
		}
	}

	public List<Product> getAllProduct(){
		return pd.findAllProduct();		
	}


	public List<Product> findProductByid(int id){
		return pd.findProductByid(id);
		
	}
	
}
