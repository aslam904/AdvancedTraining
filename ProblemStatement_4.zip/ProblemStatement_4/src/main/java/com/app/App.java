package com.app;

import java.util.Scanner;

import com.bean.Users;
import com.service.UserService;

public class App {

	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserService us=new UserService();
		String fname="Aslam";
		String address="Tenkasi";
		String email="aslam904@gmail.com";
		String user_name="aslam904";
		String password="123";
		
		Users user = new Users(fname, address, email,user_name,password);
		String result = us.storeUser(user);
		System.out.println(result);

	}

}
