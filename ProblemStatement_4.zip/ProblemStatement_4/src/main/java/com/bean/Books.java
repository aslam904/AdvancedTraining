package com.bean;

public class Books {

	private int id;
	private String bname;
	private String author;
	private float price;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Books [id=" + id + ", bname=" + bname + ", author=" + author + ", price=" + price + "]";
	}
	public Books(int id, String bname, String author, float price) {
		super();
		this.id = id;
		this.bname = bname;
		this.author = author;
		this.price = price;
	}
	public Books() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
