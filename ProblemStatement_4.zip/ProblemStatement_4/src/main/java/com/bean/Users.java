package com.bean;

public class Users {
	
	private String fname;
	private String address;
	private String email;
	private String user_name;
	private String password;
	
	
	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Users(String fname, String address, String email, String user_name, String password) {
		super();
		this.fname = fname;
		this.address = address;
		this.email = email;
		this.user_name = user_name;
		this.password = password;
	}
	@Override
	public String toString() {
		return "Users [fname=" + fname + ", address=" + address + ", email=" + email + ", user_name=" + user_name
				+ ", password=" + password  + "]";
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	

}
