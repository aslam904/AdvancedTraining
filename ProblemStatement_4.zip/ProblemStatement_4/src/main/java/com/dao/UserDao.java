package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bean.Users;
import com.resource.DBResource;

public class UserDao {

	Connection con=DBResource.getDBConnection();

	public int storeUser(Users user) {
		try {
			
			
			PreparedStatement pre=con.prepareStatement("insert into users values(?,?,?,?,?)");
			pre.setString(1,user.getFname());
			pre.setString(2,user.getAddress());
			pre.setString(3,user.getEmail());
			pre.setString(4,user.getUser_name());
			pre.setString(5,user.getPassword());
			int res=pre.executeUpdate();
			return res;
			
		}catch(Exception e) {
			System.out.println(e);
		}
		return 0;
	}
	
	public Users getUserByUnameAndPassword(String uname, String password) {
		Users user=null;
		try {
			String query="select * from users where user_name=? and password=?";	
			PreparedStatement psmt=con.prepareStatement(query);
			psmt.setString(1, uname);
			psmt.setString(2, password);
			ResultSet rs=psmt.executeQuery();
			if(rs.next()) {
				user=new Users();
				user.setFname(rs.getString("fname"));
				user.setAddress(rs.getString("address"));
				user.setEmail(rs.getString("email"));
				user.setUser_name(uname);
				user.setPassword(password);	
			    return user;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
}
