package com.resource;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBResource {
	
	public static Connection getDBConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bookdb","java","admin@123");
			return con;
	   }catch(Exception e) {
		System.out.println(e);
		
	   }
	   return null;
    }

 }

