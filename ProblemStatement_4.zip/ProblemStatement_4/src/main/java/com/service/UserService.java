package com.service;

import com.bean.Users;
import com.dao.UserDao;

public class UserService {

	UserDao ud=new UserDao();
	public String storeUser(Users user) {
		
		if(ud.storeUser(user)>0) {
			return "Account created";
		}else {
			return "Failed";
		}		
	}
}
