package com;

import java.util.Scanner;

public class Even_till_n {

	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		
		System.out.println("Enter the number of elements");
		int n=sc.nextInt();
		int[] arr=new int[n];
		
		for(int i=0;i<n;i++) {
			arr[i]=i+1;
		}
		for(int j=0;j<arr.length;j++) {
			if(arr[j]%2==0) {
				System.out.println("The even numbers are as follows "+arr[j]);
			}
		}

	}

}
