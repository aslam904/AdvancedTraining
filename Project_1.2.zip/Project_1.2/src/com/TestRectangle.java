package com;

public class TestRectangle {
	
	public static void area(Rectangle rec) {
		double area=rec.getLength()*rec.getWidth();
		System.out.println("The area of the rectangle is "+area);
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle rec=new Rectangle(50,60);
		area(rec);
		Rectangle rec1=new Rectangle(10.876,80);
		area(rec1);
		Rectangle rec2=new Rectangle(30.876,60.9876);
		area(rec2);
		Rectangle rec3=new Rectangle();
		area(rec3);
		Rectangle rec4=new Rectangle(75,25);
		area(rec4);
		
	}
	
	
	
}
