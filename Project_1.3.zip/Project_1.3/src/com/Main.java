package com;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	static Scanner sc=new Scanner(System.in);
	
	public static ArrayList<Book> createBook() {
		
		ArrayList<Book> books=new ArrayList<Book>();
		System.out.println("Enter the number of books to create");
		
		int noOfBooks=sc.nextInt();
		for(int i=0;i<noOfBooks;i++) {
			System.out.println("Enter the book title");
			sc.nextLine();
			String title=sc.nextLine();
			System.out.println("Enter the book price");
			double price=sc.nextDouble();
			Book book=new Book(title,price);
			books.add(book);
		}
		return books;
	}
	
	public static void showBooks(ArrayList<Book> books){
		
		for(int i=0;i<books.size();i++) {
			System.out.println(books.get(i).toString());
		}
			
		
	}
	
	public static void main(String[] args) {
	
		ArrayList<Book> books=createBook();
		showBooks(books);
		

	}

}
