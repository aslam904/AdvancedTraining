package com;

public class TestRectangle {
	
	public static void areaAndPerimeter(Rectangle rec) {
		double area=rec.getLength()*rec.getWidth();
		double peri=2*(rec.getLength()+rec.getWidth());
		System.out.println("The area of the rectangle is "+area);
		System.out.println("The perimeter of the rectangle is "+peri);
		
	}


	public static void main(String[] args) {
		
		//Using constructors
		System.out.println("------------------using constructors----------");
		Rectangle rec=new Rectangle(30,10);
		areaAndPerimeter(rec);
		
		Rectangle rec1=new Rectangle(17.345,80);
		areaAndPerimeter(rec1);
		
		Rectangle rec2=new Rectangle(10.876,15.9876);
		areaAndPerimeter(rec2);
		
		Rectangle rec3=new Rectangle();
		areaAndPerimeter(rec3);
		
		Rectangle rec4=new Rectangle(75,25);
		areaAndPerimeter(rec4);
		
		System.out.println("----------using getters and setters-------------");
		//Using getters and setters
		Rectangle rec5=new Rectangle();
		rec5.setLength(17.987);
		rec5.setWidth(19.675);
		areaAndPerimeter(rec5);
		
		Rectangle rec6=new Rectangle();
		rec6.setLength(50);
		rec6.setWidth(10);
		areaAndPerimeter(rec6);
		
		Rectangle rec7=new Rectangle();
		rec7.setLength(15);
		rec7.setWidth(80);
		areaAndPerimeter(rec7);
		
		
		
	}
	
	
	
}
