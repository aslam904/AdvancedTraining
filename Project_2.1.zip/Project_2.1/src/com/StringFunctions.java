package com;

import java.util.Scanner;

public class StringFunctions {

	static Scanner sc=new Scanner(System.in);
	public static void palindrome(String word) {
		System.out.println("Before reversing: "+word);
		StringBuilder builder=new StringBuilder();
		builder.append(word);
		String rev=builder.reverse().toString();
		System.out.println("After reversing: "+builder);
		if(word.equals(rev)) {
			System.out.println("It is a palindrome");
		}else {
			System.out.println("It is not a palindrome");
		}
		
	}
	public static void main(String[] args) {
		System.out.println("Enter the word ");
		String word=sc.nextLine();
		System.out.println("The length of the string is "+word.length());
		System.out.println("The word in upper case "+word.toUpperCase());
		palindrome(word);

	}

}
