package com;

import java.util.Scanner;

public class Fibonacci {


	public static void fibo(int num1,int num2,int n) {
		int num;
		for(int i=1;i<=13;i++) {
			num=num1+num2;
			System.out.println("The value "+i+" is "+num);
			num1=num2;
			num2=num;
		}
	}

	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the first number");
		int first_number=sc.nextInt();
		System.out.println("Enter the second number");
		int second_number=sc.nextInt();
		int n=13;
		fibo(first_number,second_number,n);
	
	}
	
}
