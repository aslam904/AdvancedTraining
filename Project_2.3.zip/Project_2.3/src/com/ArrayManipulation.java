package com;


public class ArrayManipulation {

	public static int smallest(int[] arr) {
		for(int i=0;i<arr.length;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i]>arr[j]) {
					int temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		return arr[0];
	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] A = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		int Partialsum=0;
		int sum=0;
		for(int i=0;i<14;i++) {
			Partialsum+=A[i];
		}
		System.out.println("The value of sum from 0th index to 14th index is "+Partialsum );
		System.out.println("Updating array");
		A[15]=Partialsum;
		System.out.println("Finding avg of the updated array");
		for(int i=0;i<A.length;i++) {
			sum+=A[i];
		}
		double avg=sum/A.length;
		System.out.println("The average is "+avg);
		A[16]=(int) avg;
		System.out.println("Finding the smallest element of the array");
		int[] cpyArr=new int[A.length];
		for(int i=0;i<cpyArr.length;i++) {
			cpyArr[i]=A[i];
		}
		A[17]=smallest(cpyArr);
		System.out.println("Printing the whole array ");
		for(int i=0;i<A.length;i++) {
			System.out.println("The elements in the index "+i+" is "+A[i]);
		}
		
	
	}

}
