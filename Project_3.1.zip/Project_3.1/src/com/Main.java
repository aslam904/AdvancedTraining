package com;

import java.util.ArrayList;

public class Main {
	
	
	public static class Piano extends Instrument{
		public void play() {
			System.out.println("Piano is playing tan tan tan tan");
		}
	}


	public static class Flute extends Instrument{
		public void play() {
			System.out.println("Flute is playing toot toot toot");
		}
	}

	public static class Guitar extends Instrument{
		public void play() {
			System.out.println("Guitar is playing tin tin tin");
		}
	}

	public static void main(String[] args) {
		ArrayList<Instrument> ins=new ArrayList<Instrument>();
		ins.add(null);
		ins.add(new Guitar());
		ins.add(new Flute());
		ins.add(new Guitar());
		ins.add(new Piano());
		ins.add(null);
		ins.add(new Piano());
		ins.add(new Guitar());
		ins.add(new Flute());
		ins.add(new Piano());
		
		for (int i=0;i<ins.size();i++) {
			if(ins.get(i) instanceof Piano) {
				System.out.println("Yes it is a piano");
				ins.get(i).play();
			}else if(ins.get(i) instanceof Guitar) {
				System.out.println("Yes it is a guitar");
				ins.get(i).play();
			}else if(ins.get(i) instanceof Flute) {
				System.out.println("Yes it is a flute");
				ins.get(i).play();
			}else {
				System.out.println("Not an instrument");
			}
		}
	}

}
