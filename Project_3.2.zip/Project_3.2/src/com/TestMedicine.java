package com;

import java.util.ArrayList;

public class TestMedicine  {
	
	public static  class Tablet implements MedicineInfo{

		@Override
		public void displayLabel() {
			// TODO Auto-generated method stub
			System.out.println("Store in a cool dry place ");
		}
		
	}
	
	public static  class Ointment implements MedicineInfo{

		@Override
		public void displayLabel() {
			// TODO Auto-generated method stub
			System.out.println("For external use only ");
		}
		
	}
	
	
	
	public static  class Syrup implements MedicineInfo{

		@Override
		public void displayLabel() {
			// TODO Auto-generated method stub
			System.out.println("Consult physician before taking ");
		}
		
	}
	
	public static void displayLabel() {
		System.out.println("Company : Apollo Pharmacy");
		System.out.println("Address : Chennai");
	}

	public static void main(String[] args) {
		
		ArrayList<MedicineInfo> medicine=new ArrayList<MedicineInfo>();
		Tablet tab=new Tablet();
		Ointment oin=new Ointment();
		Syrup syrup=new Syrup();
		
		double i = Math.random()*4;
		int j = (int) i;
		System.out.println("The choice generated is "+j);
		//
		switch(j) {
		case 0: 
			medicine.add(new Tablet());
			System.out.println("Tablet object created");
			tab.displayLabel();
			break;
		case 1:
			medicine.add(new Ointment());
			System.out.println("Ointment object created");
			oin.displayLabel();
			break;
		case 2:
			medicine.add(new Syrup());
			System.out.println("Syrup object created");
			syrup.displayLabel();
			break;
		case 3:
			displayLabel();
			break;
		default:
			break;
			
		}
		

	}

}
