package com;



public class BankAccount {

	private int accNo;
	private String custName;
	private String accType;
	private float balance;
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public float getBalance() throws LowBalanceException {
		if(accType.equals("savings") && this.balance<1000) {
			throw new LowBalanceException("The Overall balance is low for the savings account");
		}else if(accType.equals("current") && this.balance<5000) {
			throw new LowBalanceException("The Overall balance is low for the current account");
		}else {
			return balance;
		}
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public BankAccount(int accNo, String custName, String accType, float balance) {
		super();
		this.accNo = accNo;
		this.custName = custName;
		this.accType = accType;
		this.balance = balance;
	}
	public BankAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void deposit(float amt) throws NegativeAmountException  {
		if(amt<0) {
			throw new NegativeAmountException("Negative amount given");
		}else {
			this.balance=balance+amt;
		}
		
	}
	
	public void withdraw(float amt)throws InsufficientFundsException{
		if(this.balance<amt) {
			throw new InsufficientFundsException("Low Balance");
		}else {
			this.balance=balance-amt;
		}
	}
	
	
}
