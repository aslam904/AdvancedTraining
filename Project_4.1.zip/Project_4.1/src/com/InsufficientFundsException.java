package com;


public  class InsufficientFundsException extends Exception{
	public InsufficientFundsException(String s) {
		super(s);
	}
}