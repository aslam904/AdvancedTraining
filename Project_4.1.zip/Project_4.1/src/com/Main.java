package com;

public class Main {
	
	
	
	public static void main(String[] args) {

		try {
			BankAccount aslam=new BankAccount(123,"aslam","current",800);
			aslam.deposit(20000);
			aslam.withdraw(10000);
			System.out.println("The balance is "+aslam.getBalance());
			
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
