package com;

public  class NegativeAmountException extends Exception{
	public NegativeAmountException(String s) {
		super(s);
	}
}