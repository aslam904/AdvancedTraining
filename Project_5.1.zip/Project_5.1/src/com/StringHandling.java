package com;

public class StringHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="JAVA is Simple";
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());
		String[] splitted_string=str.split("\\s");
		
		for(String s:splitted_string) {
			System.out.println(s.charAt(0));
			System.out.println(" ");
		}
		
		String[] words=str.split("\\s"); // Change order 
		for(String s:words){  
			System.out.println(s); 
		}
		
		StringBuilder strbuild=new StringBuilder();
		strbuild.append(str);
		System.out.println(strbuild.reverse());
		System.out.println(str);
		System.out.println("The length of the sentence is "+str.length());
		
	}

}
