package com;
import java.util.Scanner;

public class StringManipulation {

	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		String word="";
		System.out.println("Enter the word to be jumbled");
		String str=sc.next();
		for(int i=0;i<str.length();i++) {
			char first_letter=str.charAt(i);
			word=word+first_letter;
			//System.out.println("The value of word is "+word);
			String jumbled_word=str.substring(i+1, str.length());
			//System.out.println("The value of jumbled_word is "+jumbled_word);
			System.out.println("The whole word is "+jumbled_word+word);
			
		}
	}

}
