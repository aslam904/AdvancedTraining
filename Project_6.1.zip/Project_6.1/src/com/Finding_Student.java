package com;

import java.util.ArrayList;
import java.util.Scanner;

public class Finding_Student {
	
	static Scanner sc=new Scanner(System.in);
	
	public static String findStudent(ArrayList<String> students,String name) {
		for(int i=0;i<students.size();i++) {
			if(students.get(i).equals(name)) {
				return "Name found"; 
			}
		}
		return null;
	}

	public static void main(String[] args) {
		
		ArrayList<String> student_names=new ArrayList<String>();
		student_names.add("aslam");
		student_names.add("anwar");
		student_names.add("aqeel");
		student_names.add("ashiq");
		student_names.add("salman");
		student_names.add("pradeep");
		student_names.add("arun");
		student_names.add("rajesh");
		student_names.add("jaffar");
		student_names.add("farook");
		student_names.add("rafik");
		student_names.add("rafik raja");
		
		System.out.println("Enter the name to be found");
		String name=sc.nextLine();
		String res=findStudent(student_names,name);
		System.out.println(res);
		

	}

}
