package com;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class Main {
	
static Scanner sc=new Scanner(System.in);
	
/*
	public static HashSet<Product> createSet() {
		HashSet<Product> fruits=new HashSet<Product>();
		System.out.println("Enter the number of products to enter ");
		int n=sc.nextInt();
		sc.nextLine();
		for(int i=0;i<n;i++) {
			System.out.println("Enter the product id");
			String id=sc.nextLine();
			System.out.println("Enter the product name");
			String name=sc.nextLine();
			Product prod=new Product(id,name);
			fruits.add(prod);	
		}
		return fruits;
	}
*/	
	public static void printProducts(HashSet<Product> fruits) {
		Iterator<Product> iter=fruits.iterator();
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
	}
	
	public static String findProduct(HashSet<Product> fruits,Product prod) {
		if(fruits.contains(prod)) {
			return "Found";
		}else {
			return "Not found";
		}
	}
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//HashSet<Product> products=createSet();
		
		HashSet<Product> products=new HashSet<Product>();
		
		
		Product prod1=new Product("P001","Apple");
		Product prod2=new Product("P002","Orange");
		Product prod3=new Product("P003","Banana");
		Product prod4=new Product("P004","Litchi");
		Product prod5=new Product("P005","Mango");
		Product prod6=new Product("P006","Strawberry");
		Product prod7=new Product("P007","Blackcurrent");
		Product prod8=new Product("P008","Grapes");
		Product prod9=new Product("P009","Blueberry");
		Product prod10=new Product("P010","Raspberry");
		
		products.add(prod1);
		products.add(prod2);
		products.add(prod3);
		products.add(prod4);
		products.add(prod5);
		products.add(prod6);
		products.add(prod7);
		products.add(prod8);
		products.add(prod9);
		products.add(prod10);
		
		System.out.println(findProduct(products, prod10));
		System.out.println(	findProduct(products, new Product("P011","Dates")));
		System.out.println("Before Removing ");
		printProducts(products);
		products.remove(prod1);
		System.out.println("After Removing");
		printProducts(products);
	
	}

}
