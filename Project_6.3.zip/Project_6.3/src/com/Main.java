package com;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Main {

	static Scanner sc=new Scanner(System.in);
	public static ArrayList<Employee> addInput() {
		ArrayList<Employee>emp=new ArrayList<Employee>();
		System.out.println("Enter the number of elements to add in arraylist");
		int n=sc.nextInt();
		for(int i=0;i<n;i++) {
			System.out.println("Enter employee id");
			int id=sc.nextInt();
			sc.nextLine();
			System.out.println("Enter the employee name ");
			String name=sc.nextLine();
			System.out.println("Enter the employee address");
			String address=sc.nextLine();
			Employee employee=new Employee(id,name,address);
			emp.add(employee);
		}
		return emp;

	}
	
	public static void display(ArrayList<Employee> emp) {
		Iterator<Employee>iter=emp.iterator();
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Employee>emp=addInput();
		display(emp);
		
	}

}
