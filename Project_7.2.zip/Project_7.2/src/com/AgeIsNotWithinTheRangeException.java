package com;

public class AgeIsNotWithinTheRangeException extends Exception {
	public AgeIsNotWithinTheRangeException(String s) {
		super(s);
	}

}
