package com;



import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class Main {
	static Scanner sc=new Scanner(System.in); 
	
	public static void createAndWriteInFile(Student s) {
		String fileName = "file1.txt";
		    try {
		      File objFile = new File(fileName);
		      if (objFile.exists() == false) {
		        if (objFile.createNewFile()) {
		          System.out.println("File created successfully.");
		        } else {
		          System.out.println("File creation failed!!!");
		          System.exit(0);
		        }
		      }
		    
		      FileOutputStream fileOut = new FileOutputStream(objFile);
		      ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
		      objectOut.writeObject(s);
		      objectOut.close();
		      System.out.println("File saved.");
		    } catch (Exception Ex) {
		      System.out.println("Exception : " + Ex.toString());
		    }
		  }
	

    public static void main(String args[])throws Exception{
         BufferedReader b=new BufferedReader(new InputStreamReader(System.in));

         System.out.print("Enter roll number: ");
         int roll = Integer.parseInt(b.readLine());
         System.out.print("\nEnter name: ");
         String name = b.readLine();
         System.out.print("\nEnter age: ");
         int age = Integer.parseInt(b.readLine());
         System.out.print("\nEnter course: ");
         String course = b.readLine();
         Student s = new Student(roll,name,age,course);
         s.display();
         String choice=sc.next();
         if(choice.equals("yes")) {
        	 createAndWriteInFile(s);
         }
        	 
         
    }       
}
