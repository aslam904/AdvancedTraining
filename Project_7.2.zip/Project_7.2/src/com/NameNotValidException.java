package com;

class NameNotValidException extends Exception {
	public NameNotValidException(String s){
         super(s);
    }
}
