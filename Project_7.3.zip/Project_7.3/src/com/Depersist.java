package com;

import java.io.*;  
class Depersist{  
 public static void main(String args[]){  
  try{  
  
  ObjectInputStream in=new ObjectInputStream(new FileInputStream("f.txt"));  
  Product p=(Product)in.readObject();  
  System.out.println(p.getProduct_id()+" "+p.getProduct_name());
  Product p1=(Product)in.readObject();  
  System.out.println(p1.getProduct_id()+" "+p1.getProduct_name());  
  Product p2=(Product)in.readObject();  
  System.out.println(p2.getProduct_id()+" "+p2.getProduct_name());  
  Product p3=(Product)in.readObject();  
  System.out.println(p3.getProduct_id()+" "+p3.getProduct_name());  
  Product p4=(Product)in.readObject();  
  System.out.println(p4.getProduct_id()+" "+p4.getProduct_name());  
  Product p5=(Product)in.readObject();  
  System.out.println(p5.getProduct_id()+" "+p5.getProduct_name());  
  Product p6=(Product)in.readObject();  
  System.out.println(p6.getProduct_id()+" "+p6.getProduct_name());  
  Product p7=(Product)in.readObject();  
  System.out.println(p7.getProduct_id()+" "+p7.getProduct_name());  
  Product p8=(Product)in.readObject();  
  System.out.println(p8.getProduct_id()+" "+p8.getProduct_name());  
  Product p9=(Product)in.readObject();  
  System.out.println(p9.getProduct_id()+" "+p9.getProduct_name());  
   
  in.close();  
  }catch(Exception e){System.out.println(e);}  
 }  
}  