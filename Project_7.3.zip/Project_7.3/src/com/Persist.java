package com;

import java.io.*;    
class Persist{    
 public static void main(String args[]){    
  try{    
    
  Product p1 =new Product("P001","apple");
  Product p2 =new Product("P002","banana");    
  Product p3 =new Product("P003","orange");    
  Product p4 =new Product("P004","mango");    
  Product p5 =new Product("P005","strawberry");    
  Product p6 =new Product("P006","raspberry");    
  Product p7 =new Product("P007","litchi");    
  Product p8 =new Product("P008","custardapple");    
  Product p9 =new Product("P009","blueberry");    
  Product p10 =new Product("P010","blackberry");    
  
  FileOutputStream fout=new FileOutputStream("f.txt");    
  ObjectOutputStream out=new ObjectOutputStream(fout);    
  out.writeObject(p1);
  out.writeObject(p2);    
  out.writeObject(p3);    
  out.writeObject(p4);    
  out.writeObject(p5);    
  out.writeObject(p6);    
  out.writeObject(p7);    
  out.writeObject(p8);    
  out.writeObject(p9);    
  out.writeObject(p10);    
  
  out.flush();    
  out.close();    
  System.out.println("success");    
  }catch(Exception e){System.out.println(e);}    
 }    
}    
